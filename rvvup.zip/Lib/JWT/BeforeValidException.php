<?php

namespace Rvvup\Payments\Lib\JWT;

class BeforeValidException extends \UnexpectedValueException
{
}
