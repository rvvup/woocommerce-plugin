<?php

namespace Rvvup\Payments\Lib\JWT;

class ExpiredException extends \UnexpectedValueException
{
}
