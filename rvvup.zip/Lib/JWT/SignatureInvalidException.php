<?php

namespace Rvvup\Payments\Lib\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
