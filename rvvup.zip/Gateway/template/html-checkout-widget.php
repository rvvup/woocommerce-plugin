<?php
/** @var \Rvvup\Payments\Gateway\Dynamic $this */
$position = $this->settings["mobile_position"] ?? "bottom"; ?>
<iframe class="rvvup-iframe" src="<?= $this->getSummaryUrl() ?>"></iframe>

<div id="rvvup-modal-<?= $this->id ?>" class="rvvup-modal">
    <div class="rvvup-dialog slide-in-<?= $position ?>" role="dialog" aria-modal="true">
        <iframe class="rvvup-iframe" src=""></iframe>
    </div>
</div>
