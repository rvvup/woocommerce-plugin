<?php
$subsection = isset($_GET["subsection"]) ? $_GET["subsection"] : "main";
$tabs = apply_filters("wc_rvvup_settings_nav_tabs", []);
$last = count($tabs);
$idx = 0;
$tab_active = false;
?>
<div>
    <img style="height:50px;margin-bottom: 15px;margin-left:15px" src="<?= RVVUP_PLUGIN_URL .
        "/assets/images/rvvup_logo_black_150dpi.png" ?>"/>
</div>
<div>
    <?php foreach ($tabs as $id => $tab):
        $idx++; ?>
        <a class="nav-tab <?php if ($subsection === $id || (!$tab_active && $last === $idx)) {
            echo "nav-tab-active";
            $tab_active = true;
        } ?>"
           href="<?= admin_url(
               "admin.php?page=wc-settings&tab=checkout&section=rvvup_gateway&subsection=" . $id
           ) ?>"><?= esc_attr($tab) ?></a>
    <?php
    endforeach; ?>
</div>
<div class="clear"></div>
