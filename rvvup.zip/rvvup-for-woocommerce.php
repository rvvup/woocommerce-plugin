<?php
/**
 * Plugin Name: Rvvup for WooCommerce
 * Description: Accept payments with Rvvup.
 * Version: 0.1.0
 * Author: Rvvup
 * Author URI: https://www.rvvup.com
 * Text Domain: rvvup-for-woocommerce
 * Tested up to: 6.0.1
 * WC tested up to: 6.6.1
 */

use Rvvup\Payments\Actions\ExpressCheckoutCartModification;
use Rvvup\Payments\Actions\ExpressCheckoutLoad;
use Rvvup\Payments\Controller\ExpressDeleteEndpoint;
use Rvvup\Payments\Controller\ExpressUpdateEndpoint;
use Rvvup\Payments\Lib\Versions;
use Rvvup\Payments\Model\AssetLoader;
use Rvvup\Payments\Model\ClosedBetaUpdater;
use Rvvup\Payments\Controller\ExpressEndpoint;
use Rvvup\Payments\Controller\LogController;
use Rvvup\Payments\Controller\WebhookEndpoint;
use Rvvup\Payments\Service\AdminViewManager;
use Rvvup\Payments\Service\CheckoutPopulate;
use Rvvup\Payments\Service\EventManager;
use Rvvup\Payments\Service\GatewayLoader;
use Rvvup\Payments\Gateway\Rvvup;
use Rvvup\Payments\Controller\ReturnEndpoint;
use Rvvup\Payments\Controller\PayOrderEndpoint;
use Rvvup\Payments\Service\OrderStatusManager;
use Rvvup\Payments\Service\PostTypesManager;
use Rvvup\Payments\Service\RefundManager;
use Rvvup\Payments\Service\RvvupRefundManager;
use Rvvup\Payments\Service\RvvupRefundRepository;
use Rvvup\Payments\Service\ViewManager;

if (!defined("ABSPATH")) {
    exit(); // Exit if accessed directly
}

define("RVVUP_PLUGIN_PATH", plugin_dir_path(__FILE__));
define("RVVUP_PLUGIN_FILE", __FILE__);
define("RVVUP_PLUGIN_URL", plugin_dir_url(__FILE__));

// Check if WooCommerce is active

try {
    require RVVUP_PLUGIN_PATH . "autoload.php";

    add_action("woocommerce_blocks_loaded", "rvvup_woocommerce_loaded");

    add_filter("plugin_action_links_" . plugin_basename(__FILE__), "rvvup_add_plugin_actions_links");

    /**
     * Load Gateway and Filters/Action after the woocommerce plugin is loaded,
     * if the Rvvup Plugin is not configured, then does nothing.
     */
    function rvvup_woocommerce_loaded()
    {
        if ((new Rvvup())->needs_setup()) {
            add_filter("woocommerce_payment_gateways", [GatewayLoader::class, "loadInitialSetupGateway"]);
            return;
        }

        //Load payment gateways
        new GatewayLoader();

        // Register Custom Post Types
        PostTypesManager::getInstance()->init();

        // Register Rvvup Refunds associated Services
        RvvupRefundRepository::getInstance()->init();
        RvvupRefundManager::getInstance()->init();
        RefundManager::getInstance()->init();

        // Register custom order statuses.
        OrderStatusManager::getInstance()->init();

        //Woocommerce filters and actions
        add_filter("woocommerce_short_description", "rvvup_addRestrictionPdpMessage");
        add_action("woocommerce_before_checkout_form", "rvvup_addRestrictionCheckoutMessage");

        ViewManager::getInstance()->init();
        AdminViewManager::getInstance()->init();

        add_action("woocommerce_product_options_general_product_data", "rvvup_addRestrictionField");
        add_action("woocommerce_process_product_meta", "rvvup_saveRestrictionField");

        /**
         * Load static asset files (css/js)
         */
        add_action("wp_enqueue_scripts", [AssetLoader::class, "load"]);
        add_action("admin_enqueue_scripts", [AssetLoader::class, "admin"]);
        register_deactivation_hook(RVVUP_PLUGIN_FILE, "rvvup_deactivatePlugin");
        register_uninstall_hook(RVVUP_PLUGIN_FILE, "rvvup_uninstallPlugin");

        /**
         * Register return and webhook URL with WooCommerce API
         */
        add_action("woocommerce_api_rvvup-webhook", [WebhookEndpoint::class, "execute"]);
        add_action("woocommerce_api_rvvup/webhook", [WebhookEndpoint::class, "execute"]);
        add_action("woocommerce_api_rvvup-return", [ReturnEndpoint::class, "execute"]);
        add_action("woocommerce_api_rvvup/return", [ReturnEndpoint::class, "execute"]);
        add_action("wc_ajax_" . PayOrderEndpoint::ENDPOINT, [PayOrderEndpoint::class, "execute"]);
        add_action("wc_ajax_" . ExpressEndpoint::ENDPOINT, [ExpressEndpoint::class, "execute"]);
        add_action("wc_ajax_" . ExpressUpdateEndpoint::ENDPOINT, [ExpressUpdateEndpoint::class, "execute"]);
        add_action("wc_ajax_" . ExpressDeleteEndpoint::ENDPOINT, [ExpressDeleteEndpoint::class, "execute"]);
        add_filter("woocommerce_checkout_get_value", [CheckoutPopulate::class, "rvvup_populate_checkout"], null, 2);

        /**
         * Ensure only Express payments show on Express Payments transactions
         */
        new ExpressCheckoutLoad();
        new ExpressCheckoutCartModification();
    }

    /**
     * Add a settings link to the plugin on the admin page
     */
    function rvvup_add_plugin_actions_links($links)
    {
        $settings_link = [
            '<a href="admin.php?page=wc-settings&tab=checkout&section=rvvup_gateway">' .
            __("Settings", "rvvup-for-woocommerce") .
            "</a>",
        ];
        return array_merge($settings_link, $links);
    }
    /**
     * Adds the checkbox to the product edit form in the admin
     */
    function rvvup_addRestrictionField()
    {
        woocommerce_wp_checkbox([
            "id" => "_rvvup_restricted",
            "label" => __("Is product restricted", "rvvup-for-woocommerce"),
        ]);
    }

    /**
     * Save the value of the checkbox to the product metadata when the product is saved
     * @param $post_id
     */
    function rvvup_saveRestrictionField($post_id)
    {
        $isRestricted = isset($_POST["_rvvup_restricted"]) ? "yes" : "no";
        update_post_meta($post_id, "_rvvup_restricted", esc_attr($isRestricted));
    }

    /**
     * Add the restriction message to the product page if the item is restricted
     * @param $html
     * @return string
     */
    function rvvup_addRestrictionPdpMessage($html)
    {
        $id = get_the_ID();
        if (isset($id)) {
            $isRestricted = get_post_meta($id, "_rvvup_restricted", true);
            if ($isRestricted === "yes") {
                $rvvup = new Rvvup();
                $message = $rvvup->settings["restriction_message_pdp"];
                $html .= "<aside aria-live role='status'>$message</aside>";
            }
        }
        return $html;
    }

    /**
     * Show a notice message in the checkout if anything in the cart is restricted
     */
    function rvvup_addRestrictionCheckoutMessage()
    {
        $rvvup = new Rvvup();
        if ($rvvup->settings["restriction_message_checkout_enabled"] ?? "" === "yes") {
            foreach (WC()->cart->get_cart() as $item) {
                $id = $item["data"]->get_id();
                $isRestricted = get_post_meta($id, "_rvvup_restricted", true);
                if ($isRestricted === "yes") {
                    wc_add_notice($rvvup->settings["restriction_message_checkout"], "notice");
                    break;
                }
            }
        }
    }

    function getCheckoutIconPath($method)
    {
        $theme = "checkout";
        if ($method === "CLEARPAY") {
            $theme = (new Rvvup())->settings["clearpay_theme"] ?? "black-on-mint";
        }
        $path = sprintf("/assets/svg/%s/checkout/%s.svg", strtolower($method), $theme);
        if (file_exists(RVVUP_PLUGIN_PATH . $path)) {
            return RVVUP_PLUGIN_URL . $path . "?version=" . urlencode(Versions::getPluginVersion());
        }
        return null;
    }

    /**
     * Actions to perform when plugin is deactivated.
     * Executed only if WooCommerce is installed.
     *
     * @return void
     */
    function rvvup_deactivatePlugin()
    {
        if (!is_admin()) {
            return;
        }

        EventManager::getInstance()->dispatchPluginDisabledEvent("Wordpress Plugin Deactivated");
    }

    /**
     * Actions to perform when plugin is activated.
     *
     * @return void
     */
    function rvvup_activatePlugin()
    {
        if (!is_admin()) {
            return;
        }

        EventManager::getInstance()->dispatchPluginEnabledEvent("Wordpress Plugin Activated");
    }

    /**
     * Actions to perform when plugin is uninstalled.
     * Executed only if WooCommerce is installed.
     *
     * @return void
     */
    function rvvup_uninstallPlugin()
    {
        if (!is_admin()) {
            return;
        }

        EventManager::getInstance()->dispatchPluginDisabledEvent("Wordpress Plugin Uninstalled");
    }

    add_action("wp_ajax_rvvup_log", [LogController::class, "execute"]);

    /**
     * Supply order URL if present in order object
     */
    add_filter(
        "woocommerce_get_transaction_url",
        function ($url, $order, $method) {
            /** \WC_Order $order */
            if ($method instanceof Rvvup) {
                return $order->get_meta("_rvvup_url");
            }
            return $url;
        },
        10,
        3
    );

    /**
     * By default, the WooCommerce checkout does not output notices, so we will print them above the thank-you template
     */
    add_action(
        "woocommerce_before_template_part",
        function ($template) {
            if ("checkout/thankyou.php" === $template) {
                wc_print_notices();
            }
        },
        10,
        1
    );

    /**
     * Initialise the auto-update logic for the closed-beta stage
     */
    new ClosedBetaUpdater();
}
catch (\Exception $exception) {

}

register_activation_hook(RVVUP_PLUGIN_PATH . "/" . RVVUP_PLUGIN_FILE, "rvvup_activatePlugin");
