<?php

declare(strict_types=1);

namespace Rvvup\Payments\Exceptions;

use Exception;

class ConfigException extends Exception
{
    //
}
