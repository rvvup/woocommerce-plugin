<?php

declare(strict_types=1);

namespace Rvvup\Payments\Exceptions;

if (!defined("ABSPATH")) {
    exit(); // Exit if accessed directly
}

use Exception;

class InvalidActionException extends Exception
{
    //
}
