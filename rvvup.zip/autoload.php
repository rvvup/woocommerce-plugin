<?php declare(strict_types=1);

spl_autoload_register(function ($class) {
    if (strpos($class, "Rvvup\Payments") === 0) {
        $localPath = ltrim(str_replace(["Rvvup\Payments", "\\"], ["", "/"], $class), "/");
        $path = RVVUP_PLUGIN_PATH . $localPath . ".php";
        if (file_exists($path)) {
            require_once $path;
        }
    }
});
