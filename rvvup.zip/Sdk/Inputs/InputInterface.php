<?php

declare(strict_types=1);

namespace Rvvup\Payments\Sdk\Inputs;

interface InputInterface
{
    // Placeholder Interface for TypeHinting & Future implementations.
}
