<?php declare(strict_types=1);

namespace Rvvup\Payments\Controller;

class LogController
{
    public static function execute()
    {
        $path = \WC_Log_Handler_File::get_log_file_path("log");
        if (!file_exists($path)) {
            http_response_code(404);
            header("content-type: text/html; charset=utf-8");
            echo "<script>alert('No log file');history.back()</script>";
            die();
        }

        $logData = file_get_contents($path);
        http_response_code(200);
        header("content-disposition: attachment; filename=\"rvvup.log\"");
        echo $logData;
        die();
    }
}
