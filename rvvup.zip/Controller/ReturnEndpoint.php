<?php declare(strict_types=1);

namespace Rvvup\Payments\Controller;

if (!defined("ABSPATH")) {
    exit(); // Exit if accessed directly
}

use Rvvup\Payments\Contract\PaymentMethodInterface;
use Rvvup\Payments\Service\GatewaySettingsManager;
use Rvvup\Payments\Service\LoggerManager;
use Rvvup\Payments\Service\SdkProxy;

class ReturnEndpoint
{
    public static function execute()
    {
        $rvvupOrderId = $_GET["rvvup-order-id"];
        $orderData = SdkProxy::getOrder($rvvupOrderId);
        $paymentStatus = $orderData["payments"][0]["status"];
        $orderId = $orderData["externalReference"];
        $orderType = $orderData["type"];
        if (isset($orderId)) {
            $order = wc_get_order($orderId);
            if (!$order) {
                wp_die(__("Order ID does not exist", "rvvup-for-woocommerce"), "Rvvup", ["response" => 502]);
            }
        } else {
            if ($orderType === "STANDARD") {
                wp_die(__("Order ID is required", "rvvup-for-woocommerce"), "Rvvup", ["response" => 400]);
            } elseif ($orderType === "EXPRESS" && $paymentStatus !== PaymentMethodInterface::STATUS_CANCELLED) {
                wp_die(__("Invalid order state", "rvvup-for-woocommerce"), "Rvvup", ["response" => 400]);
            }
        }

        if (GatewaySettingsManager::getInstance()->isDebugEnabled()) {
            LoggerManager::getInstance()->debug("redirect payment status is: " . $paymentStatus);
        }

        switch ($paymentStatus) {
            case PaymentMethodInterface::STATUS_SUCCEEDED:
                $order->payment_complete($rvvupOrderId);
                wp_redirect($order->get_checkout_order_received_url());
                break;

            case PaymentMethodInterface::STATUS_PENDING:
            case PaymentMethodInterface::STATUS_REQUIRES_ACTION:
                $order->set_transaction_id($rvvupOrderId);
                $order->add_order_note(
                    "Rvvup returned status `" . $paymentStatus . "`, placing on hold awaiting conformation"
                );
                $order->set_status("on-hold");
                $order->save();
                wc_add_notice(
                    __(
                        "Your payment is being processed and is pending confirmation. You will receive an email confirmation when the payment is confirmed."
                    ),
                    "notice"
                );
                wp_redirect($order->get_checkout_order_received_url());
                break;

            case PaymentMethodInterface::STATUS_CANCELLED:
                wc_add_notice(__("Payment canceled", "rvvup-for-woocommerce"), "error");
                $data = [
                    "externalReference" => $orderId,
                    "id" => $rvvupOrderId,
                ];
                update_post_meta($orderId, "rvvup_order_payload", json_encode($data));
                wp_redirect(wc_get_checkout_url());
                break;

            case PaymentMethodInterface::STATUS_DECLINED:
                wc_add_notice(
                    __("Payment declined - please try another payment method", "rvvup-for-woocommerce"),
                    "error"
                );
                wp_redirect(wc_get_checkout_url());
                break;

            case PaymentMethodInterface::STATUS_EXPIRED:
                wc_add_notice(
                    __("Payment expired - please try another payment method", "rvvup-for-woocommerce"),
                    "error"
                );
                $data = [
                    "externalReference" => $orderId,
                    "id" => $rvvupOrderId,
                ];
                update_post_meta($orderId, "rvvup_order_payload", json_encode($data));
                wp_redirect(wc_get_checkout_url());
                break;

            case PaymentMethodInterface::STATUS_FAILED:
                wc_add_notice(
                    __("Payment failed - please try another payment method", "rvvup-for-woocommerce"),
                    "error"
                );
                $data = [
                    "externalReference" => $orderId,
                    "id" => $rvvupOrderId,
                ];
                update_post_meta($orderId, "rvvup_order_payload", json_encode($data));
                wp_redirect(wc_get_checkout_url());
                break;

            case PaymentMethodInterface::STATUS_CREATED:
                $data = [
                    "externalReference" => $orderId,
                    "id" => $rvvupOrderId,
                ];
                update_post_meta($orderId, "rvvup_order_payload", json_encode($data));
                wp_redirect(wc_get_checkout_url());
                break;

            default:
                wc_add_notice(
                    __("Sorry, something went wrong while processing the payment.", "rvvup-for-woocommerce"),
                    "error"
                );
                wp_redirect(wc_get_checkout_url());
        }
    }
}
