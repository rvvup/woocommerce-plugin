<?php

declare(strict_types=1);

namespace Rvvup\Payments\Contract;
interface PaymentMethodInterface
{
    const STATUS_REQUIRES_ACTION = "REQUIRES_ACTION";

    const STATUS_CREATED = "CREATED";

    const STATUS_EXPIRED = "EXPIRED";

    const STATUS_FAILED = "FAILED";

    const STATUS_PENDING = "PENDING";

    const STATUS_SUCCEEDED = "SUCCEEDED";

    const STATUS_CANCELLED = "CANCELLED";

    const STATUS_DECLINED = "DECLINED";
}
