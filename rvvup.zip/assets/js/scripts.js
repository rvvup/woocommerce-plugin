(function ($) {
  var $lastFocusedEl;
  var $captureUrl;
  var $cancelUrl;
  var $selectedMethod;
  var $cancelledModal = false;

  // managed by checkout-app through postMessage
  var isClosePrevented = false;
  var placeOrderForm = $("form.checkout");
  if (!placeOrderForm || placeOrderForm.length === 0) {
    placeOrderForm = $("#order_review");
  }

  placeOrderForm.on("click", "#place_order", function (event) {
    $selectedMethod = $("#payment .wc_payment_method:has(input:checked)");

    // Only trigger logic for Rvvup payment methods
    if (!$selectedMethod.is('[class*="payment_method_rvvup_gateway_"]')) return;

    $lastFocusedEl = this;

    event.preventDefault();
    var requestOptions = getRequestOptions();
    if (requestOptions.checkoutForm) {
      blockElement(requestOptions.checkoutForm);
    }

    doCheckout(requestOptions)
      .then((data) => {
        $cancelUrl = data.paymentActions.cancel.redirect_url;
        showModal(data.paymentActions.authorization.redirect_url, $selectedMethod);
      })
      .catch((data) => {
        if (requestOptions.checkoutForm) {
          data.messages
            ? submit_error('<div class="woocommerce-error">' + data.messages + "</div>", requestOptions.checkoutForm)
            : submit_error(
                '<div class="woocommerce-error">' + wc_checkout_params.i18n_checkout_error + "</div>",
                requestOptions.checkoutForm
              );
        }
      });
  });

  $(document).on("click", function (e) {
    var targetIsModal = $(e.target).hasClass(".rvvup-dialog");
    var targetWithinModal = $(e.target).closest(".rvvup-dialog").length;

    if (targetIsModal || targetWithinModal) return;
    cancelModal();
  });

  function cancelModal() {
    if (!$cancelUrl) return;
    if (isClosePrevented) return;
    if ($cancelledModal) return;
    $cancelledModal = true;
    showModal($cancelUrl, $selectedMethod);
  }

  function getRequestOptions() {
    var checkoutForm = $("form.checkout");
    if (!checkoutForm || checkoutForm.length === 0) {
      return {
        data: $("form#order_review").serialize() + "&order_id=" + rvvup_parameters.orderId,
        url: rvvup_parameters.endpoints.payOrder,
      };
    }
    return {
      checkoutForm: checkoutForm,
      data: checkoutForm.serialize(),
      url: wc_checkout_params.checkout_url,
    };
  }

  function doCheckout(requestOptions) {
    return new Promise((resolve, reject) => {
      $.ajax({
        type: "POST",
        url: requestOptions.url,
        data: requestOptions.data,
        dataType: "json",
        success: function (e) {
          detachUnloadEventsOnSubmit();
          try {
            if (
              "success" === e.result &&
              (requestOptions.checkoutForm &&
                requestOptions.checkoutForm.triggerHandler("checkout_place_order_success", e)) !== false
            ) {
              return resolve(e);
            } else if ("failure" === e.result) {
              throw "Result failure";
            } else {
              throw "Invalid response";
            }
          } catch (error) {
            if (e.reload) {
              return void window.location.reload();
            }
            e.refresh && g(document.body).trigger("update_checkout");
            reject(e);
          }
        },
        error: function (e, t, o) {
          detachUnloadEventsOnSubmit();
          reject({ messages: o });
        },
        complete: function () {
          if (requestOptions.checkoutForm) {
            unblockElement(requestOptions.checkoutForm);
          }
        },
      });
    });
  }

  function blockElement(element, message = null) {
    element.block({
      message: message,
      overlayCSS: {
        background: "#fff",
        opacity: 0.6,
      },
    });
  }

  function unblockElement(element) {
    element.unblock();
  }

  function detachUnloadEventsOnSubmit() {
    $(window).off("beforeunload", this.handleUnloadEvent);
  }

  function submit_error(e, checkoutForm) {
    $(".woocommerce-NoticeGroup-checkout, .woocommerce-error, .woocommerce-message").remove(),
      checkoutForm.prepend('<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">' + e + "</div>"),
      checkoutForm.removeClass("processing").unblock(),
      checkoutForm.find(".input-text, select, input:checkbox").trigger("validate").trigger("blur"),
      scroll_to_notices(),
      $(document.body).trigger("checkout_error", [e]);
  }

  function scroll_to_notices() {
    var e = $(".woocommerce-NoticeGroup-updateOrderReview, .woocommerce-NoticeGroup-checkout");
    e.length || (e = $(".form.checkout"));
    $.scroll_to_notices(e);
  }

  function showModal(redirect, selectedMethod) {
    var options = {
      method: selectedMethod,
      modal: selectedMethod ? $(".rvvup-modal", selectedMethod) : $(".rvvup-modal"),
      redirect: redirect,
    };

    handleModal(options);
    window.addEventListener("focus", windowFocussed, true);
    window.addEventListener("blur", windowFocussed, true);
  }

  function resizeModalIframe(width, height) {
    const windowHeight = window.innerHeight;
    const windowWidth = window.innerWidth;

    const finalWidth = width === "max" ? windowWidth - 40 : width > windowWidth ? windowWidth : width;
    const finalHeight = height === "max" ? windowHeight - 40 : height > windowHeight ? windowHeight : height;
    jQuery(".rvvup-modal.rvvup-modal-show .rvvup-dialog").animate({ width: finalWidth, height: finalHeight }, 400);
  }

  function resizeInfoIframe(width, height, url) {
    const importantWidth = width && width !== "max" ? width + "px!important" : "auto";
    const importantHeight = height && height !== "max" ? height + "px!important" : "auto";

    // Common `.css` jQuery do not accept `!important`.
    jQuery(`.rvvup-iframe[src="${url}"]`).css("cssText", `width: ${importantWidth}; height: ${importantHeight};`);
  }

  function handlePostMessage(message) {
    switch (message.data.type) {
      case "rvvup-payment-modal|prevent-close": {
        isClosePrevented = message.data.preventClose;
        break;
      }
      case "rvvup-payment-modal|close": {
        isClosePrevented = false;
        cancelModal();
        break;
      }
      case "rvvup-payment-modal|resize": {
        resizeModalIframe(message.data.width, message.data.height);
        break;
      }
      case "rvvup-info-widget|resize":
        resizeInfoIframe(message.data.width, message.data.height, message.data.url);
        break;
    }
  }

  window.addEventListener("message", handlePostMessage, true);

  function windowFocussed() {
    var $modal = $(".rvvup-modal-show .rvvup-iframe");

    if (!$(document.activeElement).hasClass("rvvup-iframe")) {
      $modal.focus();
    }
  }

  function handleModal(options) {
    if (!options.modal.length) return;
    var modalShowClass = "rvvup-modal-show";
    var overflowClass = "rvvup-modal-is-visible";

    // Remove classes by default
    options.modal.removeClass(modalShowClass);
    $(document.body).removeClass(overflowClass);

    // Get required elements
    var modalLabel = options.method ? options.method.find("label").text().trim() : "";
    var $modalDialog = options.modal.find(".rvvup-dialog");
    var $modalIframe = options.modal.find("iframe");

    // clear width and height
    if (options.clearSize) $modalDialog.css({ width: "", height: "" });

    // Update elements
    $modalDialog.attr("aria-label", modalLabel);
    $modalIframe.attr("src", options.redirect);

    // Exit if no redirect - no need to show modal or fix body overflow
    if (!options.redirect) return;
    options.modal.addClass(modalShowClass);

    // Prevent scroll on the body
    $(document.body).addClass(overflowClass);
  }

  /**
   * PayPal Integration
   * - rendering PayPal buttons instead of Place order button section when PayPal is selected initially
   * - replacing PayPal buttons with Place order button section when payment method is changed
   */
  $("body").on("updated_checkout", handlePaymentMethod);
  $("body").on("payment_method_selected", handlePaymentMethod);

  function handlePaymentMethodSelected() {
    var selectedMethod = $("#payment input[name='payment_method']:checked").attr("value");

    /* If Express Payment session, no need to handle any more button rendering. */
    if (isExpressPaymentSession()) {
      return;
    }

    if (window.rvvup_paypal && isRvvupMethodEnabled("PAYPAL")) {
      if (selectedMethod === "rvvup_gateway_PAYPAL") {
        renderPaypalButtons();
        rvvup_toggleCheckoutPayPalMessage(true);
      } else {
        hidePaypalButtons();
        rvvup_toggleCheckoutPayPalMessage(false);
      }
    }
  }

  function handlePaymentMethod() {
    if (document.readyState === "complete") {
      handlePaymentMethodSelected();
    } else {
      /** We are adding timeout here, because of paypal sdk errors **/
      setTimeout(() => {
        handlePaymentMethodSelected();
      }, 500);
    }
  }

  function isRvvupMethodEnabled(method) {
    return $.inArray(method.toLowerCase(), rvvup_parameters.methods) > -1;
  }

  /**
   * Validate whether we have an express payment session.
   *
   * @returns {boolean}
   */
  function isExpressPaymentSession() {
    return rvvup_parameters.express.isExpress.toString() === "1" && rvvup_parameters.express.id.toString() !== "0";
  }

  var paypalButtonsContainerId = "rvvup-paypal-button";

  function renderPaypalButtonsContainer() {
    var placeOrderButton = $("#place_order");
    var container = document.createElement("div");
    container.id = paypalButtonsContainerId;
    container.style.marginTop = placeOrderButton.css("margin-top");
    $(container).insertAfter(placeOrderButton);
  }

  /**
   * Container for the buttons cannot be rendered immediately as woocommerce's JavaScript
   * is updating the DOM structure - rendering when this function is run for the first time
   */
  function renderPaypalButtons() {
    if (!document.getElementById(paypalButtonsContainerId)) {
      renderPaypalButtonsContainer();

      rvvup_paypal
        .Buttons({
          style: rvvup_getCheckoutButtonStyle(),
          createOrder: function () {
            $lastFocusedEl = this;
            $selectedMethod = $("#payment .wc_payment_method:has(input:checked)");
            var requestOptions = getRequestOptions();
            if (requestOptions.checkoutForm) {
              blockElement(requestOptions.checkoutForm);
            }

            return doCheckout(requestOptions)
              .then(function (data) {
                $captureUrl = data.paymentActions.capture.redirect_url;
                $cancelUrl = data.paymentActions.cancel.redirect_url;

                return data.paymentActions.authorization.token;
              })
              .catch((data) => {
                if (requestOptions.checkoutForm) {
                  data.messages
                    ? submit_error(
                        '<div class="woocommerce-error">' + data.messages + "</div>",
                        requestOptions.checkoutForm
                      )
                    : submit_error(
                        '<div class="woocommerce-error">' + wc_checkout_params.i18n_checkout_error + "</div>",
                        requestOptions.checkoutForm
                      );
                }
              });
          },
          onApprove: function () {
            return new Promise((resolve, reject) => {
              resolve($captureUrl);
            }).then((url) => {
              showModal(url, $selectedMethod);
            });
          },
          onCancel: function () {
            showModal($cancelUrl, $selectedMethod);
          },
          onError: function () {
            var requestOptions = getRequestOptions();
            if (requestOptions.checkoutForm) {
              submit_error(
                '<div class="woocommerce-error">' + wc_checkout_params.i18n_checkout_error + "</div>",
                requestOptions.checkoutForm
              );
            }
          },
        })
        .render("#" + paypalButtonsContainerId);
    }

    $("#place_order").addClass("rvvup-hide-element").hide();
    $("#" + paypalButtonsContainerId).show();
  }

  function hidePaypalButtons() {
    $("#place_order").removeClass("rvvup-hide-element").show();
    $("#" + paypalButtonsContainerId).hide();
  }

  function appendWooNoticeError(msg) {
    var wrapper = $(".woocommerce-notices-wrapper");
    if (wrapper.length === 0) {
      return;
    }
    var woocommerceError = wrapper.children("ul.woocommerce-error");
    if (woocommerceError.length === 0) {
      woocommerceError = $("<ul>", { class: "woocommerce-error" });
      woocommerceError.appendTo(wrapper);
    }
    $("<li>").html(msg).appendTo(woocommerceError);
  }

  function clearWooNoticeError() {
    var wrapper = $(".woocommerce-notices-wrapper");
    if (wrapper.length === 0) {
      return;
    }
    var woocommerceError = wrapper.children("ul.woocommerce-error");
    if (woocommerceError.length === 0) {
      return;
    }
    woocommerceError.remove();
  }

  $(document).ready(function () {
    var variationField = document.querySelector(".cart [name='variation_id']");
    var quantityField = document.querySelector(".cart [name='quantity']");
    var addCartButton = document.querySelector(".cart [name='add-to-cart']");

    function isGroupedProduct() {
      return $(".cart").hasClass("grouped_form");
    }

    function validateProductPageCheckout(shouldDisplayError = true, clearInitWooNoticeError = true) {
      if (clearInitWooNoticeError === true) {
        clearWooNoticeError();
      }

      if (isGroupedProduct()) {
        return true;
      }

      var hasErrors = false;
      var errorMessage = "";
      if (variationField !== null && (variationField.value.length === 0 || variationField.value === "0")) {
        errorMessage = rvvup_parameters.i18n.no_variation_selected;

        hasErrors = true;
      }

      if (quantityField === null || quantityField.value < 1) {
        errorMessage = rvvup_parameters.i18n.invalid_quantity;

        hasErrors = true;
      }

      if (shouldDisplayError === true && hasErrors === true && errorMessage.length > 0) {
        appendWooNoticeError(errorMessage);
      }

      return hasErrors === false;
    }

    function getProductsList() {
      var productId = null;
      var quantity = null;
      if (!isGroupedProduct()) {
        productId = addCartButton ? addCartButton.value : null;
        quantity = quantityField ? quantityField.value : 1;
        var variationId = variationField ? variationField.value : 0;
        var variation = {};
        /* Gather all selected attributes for product variations */
        $(".cart")
          .find(".variations select")
          .each(function () {
            var attributeValue = $(this).val() || "";

            if (attributeValue.length > 0) {
              variation[$(this).data("attribute_name") || $(this).attr("name")] = attributeValue;
            }
          });
        return [{ id: productId, quantity: quantity, variation_id: variationId, variation: variation }];
      }
      var products = [];

      var quantityElements = document.querySelectorAll(".cart [name^='quantity[']");
      for (var i = 0; i < quantityElements.length; i++) {
        quantity = quantityElements[i].value;
        if (quantity > 0) {
          productId = quantityElements[i].attributes["name"].value.replace("quantity[", "").replace("]", "");
          if (productId > 0) {
            products.push({ id: productId, quantity: quantity, variation_id: 0, variation: {} });
          }
        }
      }
      return products;
    }

    $("rvvup-express-payments").each(function (i) {
      $(this).empty();
      /* if the quantity field is not present on the page we don't handle the product type
         so do not generate the buttons when we do not have a quantity field.
      */
      var supportedProductPage = isGroupedProduct() || quantityField !== null;
      if (window.rvvup_paypal && isRvvupMethodEnabled("PAYPAL") && supportedProductPage && rvvup_isPdpButtonEnabled()) {
        var id = "rvvup-paypal-container-" + i;
        $("<div>", {
          id: id,
        }).appendTo(this);
        rvvup_paypal
          .Buttons({
            style: rvvup_getPdpButtonStyle(),
            onInit: function (data, actions) {
              if (!validateProductPageCheckout(false, false)) {
                actions.disable();
              }

              jQuery("form.cart")
                .find(":input")
                .change(function () {
                  if (validateProductPageCheckout(false)) {
                    actions.enable();

                    return;
                  }

                  actions.disable();
                });
            },
            onClick: function (data, actions) {
              return validateProductPageCheckout();
            },
            createOrder: function () {
              var requestOptions = {
                data: JSON.stringify({
                  payment_method: "rvvup_gateway_PAYPAL",
                  products: getProductsList(),
                }),
                url: rvvup_parameters.endpoints.express,
              };

              return doCheckout(requestOptions)
                .then(function (data) {
                  $captureUrl = data.paymentActions.capture.redirect_url;
                  $cancelUrl = data.paymentActions.cancel.redirect_url;

                  rvvup_parameters.express.id = data.id;
                  rvvup_parameters.express.cancel_url = data.paymentActions.cancel.redirect_url;

                  return data.paymentActions.authorization.token;
                })
                .catch((data) => {
                  clearWooNoticeError();
                  data.messages
                    ? appendWooNoticeError(data.messages)
                    : appendWooNoticeError(rvvup_parameters.i18n.generic);
                });
            },
            onApprove: function (data, actions) {
              return actions.order.get().then(function (orderData) {
                /* Prepare request data with billing & shipping addresses */
                var requestData = {
                  id: rvvup_parameters.express.id,
                  cancel_url: rvvup_parameters.express.cancel_url,
                  billing_address: {
                    first_name: orderData.payer.name.given_name,
                    last_name: orderData.payer.name.surname,
                    email_address: orderData.payer.email_address,
                    phone_number: "",
                    company: "",
                    address_line_1: "",
                    address_line_2: "",
                    city: "",
                    state: "",
                    post_code: "",
                    country_code: "",
                  },
                  shipping_address: {
                    first_name: "",
                    last_name: "",
                    email_address: "",
                    phone_number: "",
                    company: "",
                    address_line_1: "",
                    address_line_2: "",
                    city: "",
                    state: "",
                    post_code: "",
                    country_code: "",
                  },
                };

                if (orderData.payer.hasOwnProperty("address")) {
                  requestData.billing_address.address_line_1 = orderData.payer.address.hasOwnProperty("address_line_1")
                    ? orderData.payer.address.address_line_1
                    : "";
                  requestData.billing_address.address_line_2 = orderData.payer.address.hasOwnProperty("address_line_2")
                    ? orderData.payer.address.address_line_2
                    : "";
                  requestData.billing_address.city = orderData.payer.address.hasOwnProperty("admin_area_2")
                    ? orderData.payer.address.admin_area_2
                    : "";
                  requestData.billing_address.state = orderData.payer.address.hasOwnProperty("admin_area_1")
                    ? orderData.payer.address.admin_area_1
                    : "";
                  requestData.billing_address.post_code = orderData.payer.address.hasOwnProperty("postal_code")
                    ? orderData.payer.address.postal_code
                    : "";
                  requestData.billing_address.country_code = orderData.payer.address.hasOwnProperty("country_code")
                    ? orderData.payer.address.country_code
                    : "";
                }

                if (orderData.payer.hasOwnProperty("phone") && orderData.payer.phone.hasOwnProperty("phone_number")) {
                  requestData.billing_address.phone_number = orderData.payer.phone.phone_number.hasOwnProperty(
                    "national_number"
                  )
                    ? orderData.payer.phone.phone_number.national_number
                    : "";
                }

                if (orderData.purchase_units.length > 0 && orderData.purchase_units[0].hasOwnProperty("shipping")) {
                  var shippingFullName =
                    orderData.purchase_units[0].shipping.hasOwnProperty("name") &&
                    orderData.purchase_units[0].shipping.name.hasOwnProperty("full_name")
                      ? orderData.purchase_units[0].shipping.name.full_name
                      : "";
                  var shippingFullNameArray = shippingFullName.split(" ");

                  requestData.shipping_address.first_name = shippingFullNameArray.shift();

                  if (shippingFullNameArray.length > 0) {
                    requestData.shipping_address.last_name = shippingFullNameArray.join(" ");
                  }

                  if (orderData.purchase_units[0].shipping.hasOwnProperty("address")) {
                    requestData.shipping_address.address_line_1 =
                      orderData.purchase_units[0].shipping.address.hasOwnProperty("address_line_1")
                        ? orderData.purchase_units[0].shipping.address.address_line_1
                        : "";
                    requestData.shipping_address.address_line_2 =
                      orderData.purchase_units[0].shipping.address.hasOwnProperty("address_line_2")
                        ? orderData.purchase_units[0].shipping.address.address_line_2
                        : "";
                    requestData.shipping_address.city = orderData.purchase_units[0].shipping.address.hasOwnProperty(
                      "admin_area_2"
                    )
                      ? orderData.purchase_units[0].shipping.address.admin_area_2
                      : "";
                    requestData.shipping_address.state = orderData.purchase_units[0].shipping.address.hasOwnProperty(
                      "admin_area_1"
                    )
                      ? orderData.purchase_units[0].shipping.address.admin_area_1
                      : "";
                    requestData.shipping_address.post_code =
                      orderData.purchase_units[0].shipping.address.hasOwnProperty("postal_code")
                        ? orderData.purchase_units[0].shipping.address.postal_code
                        : "";
                    requestData.shipping_address.country_code =
                      orderData.purchase_units[0].shipping.address.hasOwnProperty("country_code")
                        ? orderData.purchase_units[0].shipping.address.country_code
                        : "";
                  }
                }

                var requestOptions = {
                  data: JSON.stringify(requestData),
                  url: rvvup_parameters.endpoints.expressUpdate,
                };

                return doCheckout(requestOptions)
                  .then(function () {
                    return new Promise((resolve, reject) => {
                      resolve(rvvup_parameters.urls.checkout_url);
                    }).then((url) => {
                      location.href = url;
                    });
                  })
                  .catch((data) => {
                    clearWooNoticeError();
                    data.messages
                      ? appendWooNoticeError(data.messages)
                      : appendWooNoticeError(rvvup_parameters.i18n.generic);
                  });
              });
            },
            onCancel: function () {
              var requestOptions = {
                data: JSON.stringify({
                  id: rvvup_parameters.express.id,
                }),
                url: rvvup_parameters.endpoints.expressDelete,
              };
              doCheckout(requestOptions)
                .then(function () {
                  return showModal($cancelUrl);
                })
                .catch((data) => {
                  clearWooNoticeError();
                  data.messages
                    ? appendWooNoticeError(data.messages)
                    : appendWooNoticeError(rvvup_parameters.i18n.generic);
                });
            },
            onError: function (e) {
              clearWooNoticeError();
              appendWooNoticeError(rvvup_parameters.i18n.generic);
            },
          })
          .render("#" + id);
      }
    });
  });
  $(document).on("click", "#rvvup-express-payments-cancellation-link", function (e) {
    e.preventDefault();
    $selectedMethod = $("#payment .wc_payment_method:has(input:checked)");

    var requestOptions = {
      data: JSON.stringify({
        id: rvvup_parameters.express.id,
      }),
      url: rvvup_parameters.endpoints.expressDelete,
    };
    doCheckout(requestOptions)
      .then(function () {
        return showModal(
          rvvup_parameters.express.cancel_url,
          $selectedMethod.length > 0 && $selectedMethod.is('[class*="payment_method_rvvup_gateway_"]')
            ? $selectedMethod
            : null
        );
      })
      .catch((data) => {
        clearWooNoticeError();
        data.messages ? appendWooNoticeError(data.messages) : appendWooNoticeError(rvvup_parameters.i18n.generic);
      });
  });
})(jQuery);
