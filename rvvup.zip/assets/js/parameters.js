/* Placeholder script to load rvvup_parameters object from Wordpress */
