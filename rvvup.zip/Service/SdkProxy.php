<?php declare(strict_types=1);

namespace Rvvup\Payments\Service;

use Rvvup\Payments\Exceptions\ApiException;
use Rvvup\Payments\Exceptions\ConfigException;
use Rvvup\Payments\Lib\Versions;
use Rvvup\Payments\Sdk\Curl;
use Rvvup\Payments\Sdk\Factories\Inputs\RefundCreateInputFactory;
use Rvvup\Payments\Sdk\GraphQlSdk;

/**
 * Previously we had a SdkInstanceManager class which handles instantiation of the SDK, however we realised we wanted
 * to perform some additional actions whilst performing the API calls that we wanted to perform some additional logic
 * so decided on a Proxy class that provided some additional methods around the SDK (we are mainly caching responses).
 */
class SdkProxy
{
    public const BACKEND_API_URL = "backend_api_url";
    public const MERCHANT_ID = "merchant_id";
    public const AUTH_TOKEN = "auth_token";

    /** @var GraphQlSdk */
    private static $sdk;
    /** @var array */
    private static $responses = [];

    const PRICE_CACHE_KEY = "rvvup_price_thresholds_cache";

    /**
     * @return \Rvvup\Payments\Sdk\GraphQlSdk
     * @throws \Rvvup\Payments\Exceptions\ConfigException
     */
    private static function get(): GraphQlSdk
    {
        if (self::$sdk !== null) {
            return self::$sdk;
        }

        $config = self::getConfig();

        self::$sdk = new GraphQlSdk(
            $config[self::BACKEND_API_URL],
            $config[self::MERCHANT_ID],
            $config[self::AUTH_TOKEN],
            Versions::getUserAgent(),
            new Curl(),
            wc_get_logger(),
            (bool) $config["debug"]
        );

        return self::$sdk;
    }

    /** Get plugin config
     * @throws ConfigException
     */
    private static function getConfig(): array
    {
        $config = get_option("woocommerce_rvvup_gateway_settings", null);

        if (!is_array($config)) {
            throw new ConfigException("No Rvvup gateway config available");
        }

        if (
            empty($config[self::BACKEND_API_URL]) ||
            empty($config[self::MERCHANT_ID]) ||
            empty($config[self::AUTH_TOKEN])
        ) {
            throw new ConfigException("Rvvup gateway config is missing, please fill all the data");
        }

        return $config;
    }

    /**
     * When loading the acceptable threshold for the payment methods we ideally want to read from a locally cached
     * copy, but we also want a current value. As a compromise we read from our cached copy 1st, if the ttl has expired
     * we read from the API with a short timeout. If the HTTP client returns due to exceeding the timeout we will use
     * the cached copy.
     * @return array
     * @throws \Exception
     */
    public static function getThresholds()
    {
        $cachedThreshold = get_transient(self::PRICE_CACHE_KEY);
        $args = ["0", get_woocommerce_currency(), ["timeout" => 1]];
        if (!is_array($cachedThreshold) || count($cachedThreshold) <= 0) {
            //cache is not primed
            $cachedThreshold = self::get()->getMethods(...$args);
            $processed = [];
            foreach ($cachedThreshold as $processor) {
                if (is_array($processor["limits"])) {
                    $processed[$processor["name"]] = $processor["limits"]["total"];
                    if (!isset($processed["ttl"]) && isset($processor["limits"]["expiresAt"])) {
                        $processed["ttl"] = $processor["limits"]["expiresAt"];
                    }
                }
            }
            set_transient(self::PRICE_CACHE_KEY, $processed);
            unset($cachedThreshold["ttl"]);
            return $processed;
        } else {
            $now = new \DateTime();
            if (isset($cachedThreshold["ttl"])) {
                $cachedTtl = new \DateTime($cachedThreshold["ttl"]);
                if ($cachedTtl > $now) {
                    unset($cachedThreshold["ttl"]);
                    return $cachedThreshold;
                }
            }
            $response = self::get()->getMethods(...$args);
            // We store the transient with no ttl, so we have a fallback value
            if (count($response) === 0) {
                // Likely due to timeout, DNS error or no connectivity, we should use the cached value
                unset($cachedThreshold["ttl"]);
                return $cachedThreshold;
            }
            $processed = [];
            foreach ($response as $processor) {
                if (is_array($processor["limits"])) {
                    $processed[$processor["name"]] = $processor["limits"]["total"];
                    if (!isset($processed["ttl"]) && isset($processor["limits"]["expiresAt"])) {
                        $processed["ttl"] = $processor["limits"]["expiresAt"];
                    }
                }
            }
            set_transient(self::PRICE_CACHE_KEY, $processed);
            unset($processed["ttl"]);
            return $processed;
        }
    }

    /**
     * When querying the available methods we use the result to update our cached limits/ttl
     * @param string $cartTotal
     * @return array
     * @throws \Exception
     */
    public static function getMethods(string $cartTotal)
    {
        if (!isset(self::$responses[$cartTotal])) {
            self::$responses[$cartTotal] = self::get()->getMethods($cartTotal, get_woocommerce_currency());
        }
        return self::$responses[$cartTotal];
    }

    /**
     * @param $orderData
     * @return mixed
     * @throws \Exception
     */
    public static function createOrder($orderData)
    {
        return self::get()->createOrder($orderData);
    }

    /**
     * {@inheritdoc}
     */
    public static function createPayment($paymentData)
    {
        return self::get()->createPayment($paymentData);
    }

    /**
     * {@inheritdoc}
     */
    public static function updateOrder($data)
    {
        return self::get()->updateOrder($data);
    }

    /**
     * @param $orderId
     * @return false|mixed
     * @throws \Exception
     */
    public static function getOrder($orderId)
    {
        return self::get()->getOrder($orderId);
    }

    /**
     * @param string $orderId
     * @return false|mixed
     * @throws \Exception
     */
    public static function isOrderRefundable(string $orderId)
    {
        return self::get()->isOrderRefundable($orderId);
    }

    /**
     * @param $orderId
     * @param $amount
     * @param $reason
     * @param $idempotency
     * @return false|mixed
     * @throws \Exception
     */
    public static function refundOrder($orderId, $amount, $reason, $idempotency)
    {
        return self::get()->refundOrder($orderId, $amount, $reason, $idempotency);
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public static function ping(): bool
    {
        return self::get()->ping();
    }

    /**
     * @param string $url
     * @return bool
     */
    public static function registerWebhook(string $url): bool
    {
        return self::get()->registerWebhook($url);
    }

    /**
     * @param string $eventType
     * @param string $reason
     * @return void
     * @throws \Exception
     */
    public static function createEvent(string $eventType, string $reason): void
    {
        $environmentVersions = Versions::getEnvironmentVersions();

        $data = [
            "plugin" => $environmentVersions["rvvp_plugin_version"],
            "php" => $environmentVersions["php_version"],
            "wordpress" => $environmentVersions["wordpress_version"],
            "woocommerce" => $environmentVersions["woocommerce_version"],
        ];

        self::get()->createEvent($eventType, $reason, $data);
    }

    /**
     * @param string $orderId
     * @param string $amount
     * @param string $currency
     * @param string $idempotency
     * @param string|null $reason
     * @return false|array
     * @throws \Exception
     * @throws \JsonException
     * @throws \Rvvup\Payments\Exceptions\ApiException
     * @throws \Rvvup\Payments\Sdk\Exceptions\NetworkException
     */
    public static function refundCreate(
        string $orderId,
        string $amount,
        string $currency,
        string $idempotency,
        ?string $reason = null
    ) {
        $factory = new RefundCreateInputFactory();

        $result = static::get()->refundCreate($factory->create($orderId, $amount, $currency, $idempotency, $reason));

        // If false, throw custom exception.
        if ($result === false) {
            throw new ApiException("Failed to create refund");
        }

        return $result;
    }

    /**
     * @param string $orderId
     * @return array
     * @throws \Exception
     * @throws \JsonException
     * @throws \Rvvup\Payments\Exceptions\ApiException
     * @throws \Rvvup\Payments\Exceptions\ConfigException
     * @throws \Rvvup\Payments\Sdk\Exceptions\NetworkException
     */
    public static function getOrderRefunds(string $orderId): array
    {
        $result = static::get()->getOrderRefunds($orderId);

        // If false, throw custom exception.
        if ($result === false) {
            throw new ApiException("Failed to get order refunds");
        }

        return $result;
    }
}
