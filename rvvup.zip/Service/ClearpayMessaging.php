<?php declare(strict_types=1);

namespace Rvvup\Payments\Service;

use Exception;
use WC_Product;
use WC_Product_Variation;

class ClearpayMessaging
{
    /** @var bool|null */
    private static $clearpayIsEnabled = null;

    /**
     * Add the Clearpay logo to the product page if the item price is within max/min threshold values
     * @param $html
     * @return mixed|string
     * @throws Exception
     */
    public static function addClearpayLogoPdp($html)
    {
        if (!self::shouldShowMessaging()) {
            return $html;
        }

        global $product;
        if (!($product instanceof WC_Product) || !is_product()) {
            return $html;
        }

        // If item product type is not enabled for Rvvup, no message.
        // As this is the first instance we load Clearpay messaging on PDP,
        // we do not want this displayed for product variations.
        if (!RvvupAvailable::getInstance()->isRvvupAvailableForProductByProductType($product->get_type(), false)) {
            return $html;
        }

        // If item product is restricted for CLEARPAY, no message.
        if (
            !RvvupAvailable::getInstance()->isRvvupAvailableForProductByProductId(
                (string) $product->get_id(),
                "CLEARPAY"
            )
        ) {
            return $html;
        }

        if (!self::isInThreshold($product->get_price())) {
            return $html;
        }

        // Allows for correct refreshing when changing variant.
        // ClearPay messaging is added on `filterVariantPrices` method.
        if ($product->is_type("variable")) {
            return $html;
        }

        return $html . self::getMessagingHtml($product->get_price());
    }

    public static function filterVariantPrices($prices, $product)
    {
        if (!self::shouldShowMessaging()) {
            return $prices;
        }

        // If not a product variation, no action.
        if (!$product instanceof WC_Product_Variation) {
            return $prices;
        }

        if (!RvvupAvailable::getInstance()->isRvvupAvailableForProductByProductType($product->get_type())) {
            return $prices;
        }

        // If item product is restricted for CLEARPAY, no message.
        if (
            !RvvupAvailable::getInstance()->isRvvupAvailableForProductByProductId(
                (string) $product->get_id(),
                "CLEARPAY"
            )
        ) {
            return $prices;
        }

        if (!self::isInThreshold($product->get_price())) {
            return $prices;
        }

        $prices .= self::getMessagingHtml($product->get_price());

        return $prices;
    }

    /**
     * Add the Clearpay logo to the cart page if the item price is within max/min threshold values
     */
    public static function addClearpayLogoCart()
    {
        if (!self::shouldShowMessaging()) {
            return;
        }

        if (!self::isInThreshold((string) WC()->cart->get_total(null))) {
            return;
        }

        $rvvupAvailableService = RvvupAvailable::getInstance();

        foreach (WC()->cart->get_cart() as $item) {
            // If item product type is not enabled for Rvvup, no message.
            if (!$rvvupAvailableService->isRvvupAvailableForProductByProductType($item["data"]->get_type())) {
                return;
            }

            // If item product is restricted for CLEARPAY, no message.
            if (
                !$rvvupAvailableService->isRvvupAvailableForProductByProductId(
                    (string) $item["data"]->get_id(),
                    "CLEARPAY"
                )
            ) {
                return;
            }
        }

        echo self::getMessagingHtml(WC()->cart->get_total(null));
    }

    /**
     * Determine if Clearpay messaging should be shown, factoring in WooCommerce settings and Rvvup settings
     * @return bool
     * @throws \Exception
     */
    private static function shouldShowMessaging(): bool
    {
        try {
            if (!GatewaySettingsManager::getInstance()->isEnabled()) {
                return false;
            }

            return GatewaySettingsManager::getInstance()->shouldShowClearPayMessaging() && self::isClearpayEnabled();
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Check Rvvup API to see if Clearpay is available
     * @return bool
     * @throws Exception
     */
    private static function isClearpayEnabled(): bool
    {
        if (null === self::$clearpayIsEnabled) {
            $methods = SdkProxy::getMethods("0");
            $isEnabled = false;
            foreach ($methods as $method) {
                if ($method["name"] === "CLEARPAY") {
                    $isEnabled = true;
                    break;
                }
            }
            self::$clearpayIsEnabled = $isEnabled;
        }
        return self::$clearpayIsEnabled;
    }

    /**
     * Should Clearpay messaging and iconography be show for specified product?
     * @param $price
     * @return bool
     */
    private static function isInThreshold($price): bool
    {
        return ClearpayThresholdManager::getInstance()->get((string) $price, get_woocommerce_currency());
    }

    /**
     * Render messaging output
     * @param $amount
     * @return string
     */
    private static function getMessagingHtml($amount)
    {
        $locale = get_locale();
        $currency = get_woocommerce_currency();
        $theme = GatewaySettingsManager::getInstance()->getClearPayTheme();
        return <<<HTML
<afterpay-placement
    data-locale="$locale"
    data-currency="$currency"
    data-amount="$amount"
    data-badge-theme="$theme"
 ></afterpay-placement>
HTML;
    }
}
